# woco-accordion
A simple, user-friendly and lightweight accordion jQuery plugin.
Website - http://chooowai.github.io/woco-accordion/

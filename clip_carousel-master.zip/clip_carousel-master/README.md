### Demo

[https://lemehovskiy.github.io/clip_carousel//demo](https://lemehovskiy.github.io/clip_carousel//demo/)